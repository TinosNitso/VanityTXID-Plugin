from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QDialog, QVBoxLayout, QLineEdit, QPlainTextEdit, QPushButton
from electroncash.i18n import _
from electroncash.plugins import BasePlugin, hook
import electroncash, subprocess, multiprocessing, threading, zipfile, shutil
from electroncash import bitcoin

class Plugin(BasePlugin):
    def __init__(self, parent, config, name):
        BasePlugin.__init__(self, parent, config, name)
        self.wallet_windows = {}
        self.wallet_payment_tabs = {}
        self.wallet_payment_lists = {}
    def on_close(self):
        """
        BasePlugin callback called when the wallet is disabled among other things.
        """
        for window in list(self.wallet_windows.values()):
            self.close_wallet(window.wallet)
        shutil.rmtree(self.parent.get_external_plugin_dir()+'\\VanityTXID')
    @hook
    def init_qt(self, qt_gui):
        """
        Hook called when a plugin is loaded (or enabled).
        """
        # We get this multiple times.  Only handle it once, if unhandled.
        if len(self.wallet_windows):
            return
        Dir=self.parent.get_external_plugin_dir()
        Zip=zipfile.ZipFile(Dir+'\\VanityTXID-Plugin.zip')
        for Item in Zip.namelist(): 
            if 'bin' in Item: Zip.extract(Item,Dir+'\\VanityTXID')
        Zip.close()
        # These are per-wallet windows.
        for window in qt_gui.windows:
            self.load_wallet(window.wallet, window)
    @hook
    def load_wallet(self, wallet, window):
        """
        Hook called when a wallet is loaded and a window opened for it.
        """
        wallet_name = wallet.basename()
        self.wallet_windows[wallet_name] = window
        l = Ui(window, self)
        tab = window.create_list_tab(l)
        self.wallet_payment_tabs[wallet_name] = tab
        self.wallet_payment_lists[wallet_name] = l
        window.tabs.addTab(tab, QIcon(self.parent.get_external_plugin_dir()+"\\VanityTXID\\bin\\VanityTXID-Plugin.ico"), _('VanityTXID'))
    @hook
    def close_wallet(self, wallet):
        subprocess.Popen('TaskKill /IM VanityTXID-Plugin.exe /F',creationflags=subprocess.CREATE_NO_WINDOW)
        wallet_name = wallet.basename()
        window = self.wallet_windows[wallet_name]
        del self.wallet_windows[wallet_name]
        wallet_tab = self.wallet_payment_tabs.get(wallet_name, None)
        if wallet_tab is not None:
            del self.wallet_payment_lists[wallet_name]
            del self.wallet_payment_tabs[wallet_name]
            i = window.tabs.indexOf(wallet_tab)
            window.tabs.removeTab(i)
class Ui(QDialog):
    def __init__(self, window, plugin):
        QDialog.__init__(self, window)
        self.window=window
        self.plugin=plugin

        VBox = QVBoxLayout()
        self.setLayout(VBox)

        wallet = window.wallet
        self.AddressLine=QLineEdit()
        self.AddressLine.setPlaceholderText("Paste standard BCH address (starting with 'q' or '1') here to convert it to P2SH, enabling sigscript malleability. Afterward the P2SH address will appear as a label in the Addresses tab. After sending it a coin, import it into a watching-only wallet.")
        for label in list(wallet.labels.values()):
            if not electroncash.address.Address.is_valid(label): continue
            Legacy=list(wallet.labels)[list(wallet.labels.values()).index(label)]
            if not electroncash.address.Address.is_valid(Legacy): continue
            qAddress=electroncash.address.Address.from_string(Legacy)
            if not qAddress in wallet.get_addresses(): continue
            PubKey=wallet.get_public_key(qAddress)
            scriptCode='21'+PubKey+'ac7777'
            if not qAddress.from_multisig_script(bitcoin.bfh(scriptCode)).to_cashaddr()==label: continue
            self.AddressLine.insert(label)
            break
        self.AddressLine.textEdited.connect(self.AddressGen)
        VBox.addWidget(self.AddressLine)

        self.TXBox = QPlainTextEdit()
        self.TXBox.setPlaceholderText('Paste raw TX hex here for all its VanityTXID inputs to be signed by this wallet, wherever possible, and mined with the pattern below. Pattern, message etc can all be left blank, in which case the result can be mined on a separate PC. Remember to set a higher fee, maybe 20% extra, in the watching-only wallet.')
        VBox.addWidget(self.TXBox)
        
        self.HiddenBox=QPlainTextEdit()
        self.HiddenBox.textChanged.connect(self.ShowTX)
       
        self.Pattern=QLineEdit(_('00000'))
        self.Pattern.setMaxLength(16);
        self.Pattern.setPlaceholderText('Enter desired starting pattern for TXID here. Blank is OK.')
        VBox.addWidget(self.Pattern)
        
        self.Message=QLineEdit(_('deadbeef'))
        self.Message.setPlaceholderText('Enter hex message, to appear first in all the created sigscripts. Can be blank. e.g. convert text->hex and enter hex here.')
        VBox.addWidget(self.Message)
        
        self.Threads=QLineEdit(_(str(multiprocessing.cpu_count())))
        self.Threads.setMaxLength(3);
        self.Threads.setPlaceholderText('Enter # of threads. Default is cpu_count. Integer between 1 & 256.')
        VBox.addWidget(self.Threads)

        self.Button = QPushButton(_('Sign and/or Mine'))
        self.Button.clicked.connect(self.Clicked)
        VBox.addWidget(self.Button)
        
    def Clicked(self):
        if len(self.Message.text())%2: self.Message.insert('0')
        Message=self.Message.text()
        MessageSize=int(len(Message)/2)
        
        wallet=self.window.wallet
        window=self.window
        TX=electroncash.Transaction(self.TXBox.toPlainText())
        
        Password=None
        Nonce='080000000000000000'
        for Input in range(len(TX.inputs())):
            if TX.inputs()[Input]['signatures']!=[None] or TX.inputs()[Input]['address'].to_cashaddr() not in list(wallet.labels.values()): continue
            TX.inputs()[Input]['type']='unknown'
            qAddress=electroncash.address.Address.from_string(list(wallet.labels)[list(wallet.labels.values()).index(TX.inputs()[Input]['address'].to_cashaddr())])
            PubKey=wallet.get_public_key(qAddress)
            TX.inputs()[Input]['scriptCode']='21'+PubKey+'ac7777'
            
            if wallet.has_password() and Password==None: Password=window.password_dialog()
            if wallet.is_schnorr_enabled(): Sig=electroncash.schnorr.sign(bitcoin.deserialize_privkey(wallet.export_private_key(qAddress,Password))[1],bitcoin.Hash(bitcoin.bfh(TX.serialize_preimage(Input))))
            else: Sig=TX._ecdsa_sign(bitcoin.deserialize_privkey(wallet.export_private_key(qAddress,Password))[1],bitcoin.Hash(bitcoin.bfh(TX.serialize_preimage(Input))))
            
            TX.inputs()[Input]['scriptSig']=MessageSize.to_bytes(1,'big').hex()+Message+Nonce+(len(Sig)+1).to_bytes(1,'big').hex()+Sig.hex()+'4125'+TX.inputs()[Input]['scriptCode']
            Nonce='00'
        TX=electroncash.Transaction(TX.serialize())
        
        for Input in range(len(TX.inputs())):
            if TX.inputs()[Input]['signatures']==[None]: 
                window.show_transaction(TX)
                return
                
        Pattern=' '+self.Pattern.text()
        if Pattern==' ':
            window.show_transaction(TX) 
            return
        
        Threads=' '+(int(self.Threads.text())-1).to_bytes(1,'big').hex()    #I take ' 00' means 1 since highest index is specified to C++ binary.
        NoncePos=' '+int(TX.raw.find('080000000000000000')/2+1).to_bytes(1,'big').hex()
        
        Dir=self.plugin.parent.get_external_plugin_dir()
        Command='"'+Dir+'\\VanityTXID\\bin\\VanityTXID-Plugin.exe"'+Threads+NoncePos+Pattern+' '+TX.raw
        Process=subprocess.Popen(Command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW | subprocess.BELOW_NORMAL_PRIORITY_CLASS)
        threading.Thread(target=self.Bin,args=(Process,len(TX.raw))).start()
        
        self.Button.setText('TaskKill')
        self.Button.clicked.disconnect()
        self.Button.clicked.connect(self.Cancel)
    def Bin(self,Process,lenTX):
        self.HiddenBox.setPlainText(str(Process.communicate()[0])[2:2+lenTX])
        self.Button.setText('Sign and/or Mine')
        self.Button.clicked.disconnect()
        self.Button.clicked.connect(self.Clicked)
    def ShowTX(self): self.window.show_transaction(electroncash.Transaction(self.HiddenBox.toPlainText())) 
    def Cancel(self): subprocess.Popen('TaskKill /IM VanityTXID-Plugin.exe /F',creationflags=subprocess.CREATE_NO_WINDOW)
    def AddressGen(self):
        wallet=self.window.wallet
        if not electroncash.address.Address.is_valid(self.AddressLine.text()): return
        qAddress=electroncash.address.Address.from_string(self.AddressLine.text())
        if not qAddress in wallet.get_addresses(): return
        PubKey=wallet.get_public_key(qAddress)
        scriptCode='21'+PubKey+'ac7777'
        pAddress=qAddress.from_multisig_script(bitcoin.bfh(scriptCode)).to_cashaddr()
        wallet.labels[qAddress.to_string(qAddress.FMT_LEGACY)]=pAddress
        self.AddressLine.setText(pAddress)
        wallet.save_labels()
        self.window.update_labels()